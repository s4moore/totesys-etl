def dummy():
    pass
